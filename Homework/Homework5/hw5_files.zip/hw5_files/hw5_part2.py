import hw5_util

def path_nbrs(row, col, grid):
    newbounds = []
    if row != 0:
        first = (row - 1, col)
        newbounds.append(first)
    if col != 0:
        second = (row, col - 1)
        newbounds.append(second)
    if row != len(grid)-1:
        third = (row + 1, col)
        newbounds.append(third)
    if col != len(grid[0])-1:
        fourth = (row, col + 1)
        newbounds.append(fourth)
    return newbounds

def check_nbrs(row, col, grid,x):
    newbounds = []
    if row != 0:
        first = (row - 1, col)
        newbounds.append(first)
    if col != 0:
        second = (row, col - 1)
        newbounds.append(second)
    if row != len(grid)-1:
        third = (row + 1, col)
        newbounds.append(third)
    if col != len(grid[0])-1:
        fourth = (row, col + 1)
        newbounds.append(fourth)

    if x in newbounds:
        return True
    else: return False

def downelevation():
    path = hw5_util.get_path(gridnum)
    downward = 0
    count = 0
    for i in range(len(path)):
        if count < len(path)-1:
            gridcur = int(grid[path[i][0]][path[i][1]])
            gridnext = int(grid[path[i + 1][0]][path[i + 1][1]])
            if gridcur > gridnext:
                downward += gridcur-gridnext
        else:pass
        count+=1
    return downward

def upelevation():
    path = hw5_util.get_path(gridnum)
    upward = 0
    count = 0
    for i in range(len(path)):
        if count < len(path)-1:
            gridcur = int(grid[path[i][0]][path[i][1]])
            gridnext = int(grid[path[i + 1][0]][path[i + 1][1]])
            if gridcur < gridnext:
                upward += gridnext-gridcur
        else:pass
        count+=1
    return upward

def call_path():
    path = hw5_util.get_path(gridnum)
    index = 0
    nexti = 0
    for i in range(len(path)):
        neighbors = path_nbrs(path[i][0], path[i][1], grid)
        if i+1 < len(path)-1:
            if path[i+1] in neighbors:
                index = i + 1
                nexti = index + 1
                pass
            else:
                print("Path: invalid step from {} to {}".format(path[index], path[nexti]))
                exit()
    print("Valid path")
    print("Downward {}".format(downelevation()))
    print("Upward {}".format(upelevation()))

def global_max():
    val = 0
    count = 0
    for list in grid:
        for i in range(len(list)):
            if list[i] > val:
                index = "({}, {})".format(count, i)
                val = list[i]
        count+=1
    print(index, val)

def steep():
    starts = hw5_util.get_start_locations(gridnum)
    print(starts)
    current = starts[0]
    print(current)
    currindex = int(grid[current[0]][current[1]])
    while currindex != global_max():
        currindex = int(grid[current[0]][current[1]])
        nbrs = path_nbrs(current[0], current[1], grid)
        print(nbrs)
        for i in range(len(nbrs)):
            value = int(grid[nbrs[i][0]][nbrs[i][1]])
            if (value-currindex) <= maxStep:
                current = nbrs[i]
                print(current)




gridnum = int(input("Enter a grid index less than or equal to 3 (0 to end): "))
print(gridnum)

if (gridnum-1) >= 0 and (gridnum-1) < hw5_util.num_grids():
    grid = hw5_util.get_grid(gridnum)
elif gridnum == 0:
    exit()
else:
    print("Not valid input")
    exit()

maxStep = int(input("Enter the maximum step height: "))
print(maxStep)

askprint = input("Should the path grid be printed (Y or N): ")
print(askprint)
if askprint.lower() == 'y':
    print("Grid has {} rows and {} columns".format(len(grid), len(grid[0])))

print("global max: ", end = '')
global_max()
print("===")
steep()